using UnityEngine;
using UnityEngine.InputSystem;

public class MouseLookCamera : MonoBehaviour
{
    [Header("Assign Fox Body")]
    public Transform foxBody; 

    [Header("Mouse Settings")]
    public float mouseSensitivity = 2f;
    public float minPitch = -40f;
    public float maxPitch = 75f;

    private float yaw;
    private float pitch;

    void Start()
    {
        if (!foxBody)
        {
            Debug.LogError("Fox body not assigned!");
            enabled = false;
            return;
        }

        // Lock cursor
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        yaw = foxBody.eulerAngles.y;
        pitch = 0f;

        // Makes camera a child of fox
        transform.SetParent(foxBody);
        transform.localPosition = new Vector3(0f, 1.4f, 0f); // eye level
        transform.localRotation = Quaternion.identity;
    }

    void Update()
    {
        if (Mouse.current == null) return;

        Vector2 mouseDelta = Mouse.current.delta.ReadValue();

        yaw += mouseDelta.x * mouseSensitivity;
        pitch -= mouseDelta.y * mouseSensitivity;
        pitch = Mathf.Clamp(pitch, minPitch, maxPitch);

        // Rotates fox horizontally
        foxBody.rotation = Quaternion.Euler(0f, yaw, 0f);

        // Rotates camera vertically 
        transform.localRotation = Quaternion.Euler(pitch, 0f, 0f);
    }
}
