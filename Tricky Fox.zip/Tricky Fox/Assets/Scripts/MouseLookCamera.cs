using UnityEngine;
using UnityEngine.InputSystem;

public class MouseLookCamera : MonoBehaviour
{
    public Transform target;
    public Vector3 offset = new Vector3(0, 2f, -4f);

    public float mouseSensitivity = 0.1f;
    public float followSmoothness = 12f;

    public float minY = -40f;
    public float maxY = 75f;

    [Header("Camera Collision")]
    public float collisionRadius = 0.3f;
    public float collisionOffset = 0.2f;
    public LayerMask collisionLayers;

    private float yaw;
    private float pitch;
    private float currentDistance;

    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        yaw = transform.eulerAngles.y;
        currentDistance = offset.magnitude;
    }

    void Update()
    {
        if (Mouse.current == null) return;

        Vector2 mouseDelta = Mouse.current.delta.ReadValue();

        yaw += mouseDelta.x * mouseSensitivity;
        pitch -= mouseDelta.y * mouseSensitivity;
        pitch = Mathf.Clamp(pitch, minY, maxY);
    }

    void LateUpdate()
    {
        if (!target) return;

        Quaternion rotation = Quaternion.Euler(pitch, yaw, 0f);

        Vector3 targetPoint = target.position + Vector3.up * offset.y;
        Vector3 desiredDirection = rotation * Vector3.back;

        float desiredDistance = offset.magnitude;

        // ----- Sphere cast for collision -----
        if (Physics.SphereCast(
            targetPoint,
            collisionRadius,
            desiredDirection,
            out RaycastHit hit,
            desiredDistance,
            collisionLayers,
            QueryTriggerInteraction.Ignore))
        {
            currentDistance = Mathf.Clamp(
                hit.distance - collisionOffset,
                0.5f,
                desiredDistance
            );
        }
        else
        {
            currentDistance = Mathf.Lerp(
                currentDistance,
                desiredDistance,
                followSmoothness * Time.deltaTime
            );
        }

        Vector3 finalPosition =
            targetPoint + desiredDirection * currentDistance;

        transform.position = Vector3.Lerp(
            transform.position,
            finalPosition,
            followSmoothness * Time.deltaTime
        );

        transform.LookAt(targetPoint);
    }
}
