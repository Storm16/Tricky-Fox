﻿using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerFox : MonoBehaviour
{
    public float walkSpeed = 5f;
    public float runSpeed = 15f;
    public float jumpForce = 5f;

    public float rotationSpeed = 10f; 

    private float currentMoveSpeed;
    private Rigidbody rb;
    private bool isGrounded;

    private Vector2 moveInput;
    public Transform cameraTransform;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        if (!rb)
        {
            Debug.LogError("Player needs a Rigidbody component!");
        }

        currentMoveSpeed = walkSpeed;
    }

    void Update()
    {
        if (Keyboard.current == null) return;

        float x = 0f;
        float z = 0f;

        if (Keyboard.current.wKey.isPressed) z += 1f;
        if (Keyboard.current.sKey.isPressed) z -= 1f;
        if (Keyboard.current.aKey.isPressed) x -= 1f;
        if (Keyboard.current.dKey.isPressed) x += 1f;

        moveInput = new Vector2(x, z).normalized;

        currentMoveSpeed =
            Keyboard.current.leftShiftKey.isPressed
            ? runSpeed
            : walkSpeed;

        if (Keyboard.current.spaceKey.wasPressedThisFrame && isGrounded)
        {
            Jump();
        }
    }

    void FixedUpdate()
    {
        if (!cameraTransform) return;

        Vector3 camForward = Vector3.Scale(
        cameraTransform.forward,
        new Vector3(1, 0, 1)
        ).normalized;

        Vector3 camRight = cameraTransform.right;

        Vector3 moveDirection =
            camForward * moveInput.y +
            camRight * moveInput.x;


        // ----- Movement -----
        Vector3 velocity = rb.linearVelocity;
        velocity.x = moveDirection.x * currentMoveSpeed;
        velocity.z = moveDirection.z * currentMoveSpeed;
        rb.linearVelocity = velocity;

        // ----- Rotate toward movement direction -----
        if (moveDirection.sqrMagnitude > 0.001f)
        {
            Quaternion targetRotation =
                Quaternion.LookRotation(moveDirection, Vector3.up);

            rb.rotation = Quaternion.Slerp(
                rb.rotation,
                targetRotation,
                rotationSpeed * Time.fixedDeltaTime
            );
        }
    }

    void Jump()
    {
        isGrounded = false;
        rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
    }

    void OnCollisionStay(Collision collision)
    {
        foreach (ContactPoint contact in collision.contacts)
        {
            if (contact.normal.y > 0.5f)
            {
                isGrounded = true;
                return;
            }
        }
    }
}
